﻿using Core.Entities;
using Entities.Base;

namespace Entities.Concrete
{
    public class ProductComment:CommentBase,IEntity
    {
        
    }
}