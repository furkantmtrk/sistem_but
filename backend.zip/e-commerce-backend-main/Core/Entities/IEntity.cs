﻿namespace Core.Entities
{
    //IEntity implement eden class bir veritabanı tablosudur
    public interface IEntity
    {
    }
}
